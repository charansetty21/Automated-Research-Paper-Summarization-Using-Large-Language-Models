# ResearchAI — Automated Research Paper Summarization
### Stack: HTML · CSS · JavaScript | Python Flask | MySQL

---

## Project Structure

```
research_summarizer/
├── backend/
│   ├── app.py              ← Flask REST API
│   └── requirements.txt
├── database/
│   └── schema.sql          ← MySQL schema + sample dataset
├── static/
│   ├── css/style.css
│   └── js/app.js
└── templates/
    └── index.html
```

---

## Quick Setup

### 1 — MySQL Database
```sql
mysql -u root -p < database/schema.sql
```
This creates:
- `research_summarizer` database
- 6 tables: users, papers, summaries, keywords, feedback, api_logs
- 8 sample papers with full summaries and keywords
- 2 analytics views

### 2 — Python Backend
```bash
cd backend
pip install -r requirements.txt

# Set environment variables (or edit DB_CONFIG in app.py)
export DB_HOST=localhost
export DB_USER=root
export DB_PASSWORD=yourpassword
export DB_NAME=research_summarizer

python app.py
```
Server starts at: http://localhost:5000

### 3 — Access the Website
Open: http://localhost:5000

---

## API Endpoints

| Method | Endpoint           | Description                  |
|--------|--------------------|------------------------------|
| GET    | /                  | Main website                 |
| POST   | /api/register      | Register new user            |
| POST   | /api/login         | Login                        |
| POST   | /api/logout        | Logout                       |
| GET    | /api/me            | Current user session         |
| GET    | /api/papers        | List papers (filter/search)  |
| GET    | /api/papers/<id>   | Paper detail + summary       |
| POST   | /api/papers        | Submit new paper (auth req.) |
| GET    | /api/stats         | Analytics data               |
| GET    | /api/domains       | List all domains             |
| POST   | /api/feedback      | Submit feedback rating       |

### Query Parameters for GET /api/papers
- `q` — full-text search
- `domain` — filter by domain
- `year` — filter by year
- `page` — pagination (default 1)
- `limit` — results per page (default 8)

---

## Database Schema

### papers
| Column      | Type         | Description              |
|-------------|--------------|--------------------------|
| id          | INT PK       | Auto increment           |
| title       | VARCHAR(512) | Paper title              |
| authors     | TEXT         | Author names             |
| abstract    | TEXT         | Original abstract        |
| domain      | VARCHAR(100) | Research domain          |
| year        | YEAR         | Publication year         |
| status      | ENUM         | pending/summarized/etc.  |

### summaries
| Column       | Type    | Description            |
|--------------|---------|------------------------|
| paper_id     | INT FK  | Links to papers        |
| summary_text | TEXT    | LLM-generated summary  |
| key_findings | TEXT    | Extracted findings     |
| model_used   | VARCHAR | GPT-4, Claude, etc.    |
| rouge_score  | FLOAT   | ROUGE evaluation score |
| bert_score   | FLOAT   | BERTScore              |

---

## Sample Login (after importing dataset)
Register a new account via the Sign Up button, or use the database to
manually set a password hash. The sample users have placeholder passwords.

---

## Features
- Browse and search research paper summaries
- Filter by domain and year
- Detailed view: summary, findings, methodology, conclusion, keywords
- Submit new papers (auto-summarized via Flask)
- Rate and review summaries (1-5 stars)
- Analytics dashboard with Chart.js charts
- User registration and login
- Fully responsive dark-mode UI
